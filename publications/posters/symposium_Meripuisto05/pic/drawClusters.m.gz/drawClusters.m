h2527=dlmread('hgene2527.dlm');
m2527=dlmread('mgene2527.dlm');

h20=dlmread('yellowCluster20H.dlm');
m20=dlmread('yellowCluster20M.dlm');

m20_mean=mean(m20)
h20_mean=mean(h20)

h20_mean=h20_mean(1:length(h20)-1)

m2527=[m2527 0]


figure(1)
set(axes,'FontSize',20,'LineWidth',1.5)
bar(transpose([h2527; m2527]))
axis([0.5,46.5,0,1600])
colormap('gray')

figure(2)
set(axes,'FontSize',20,'LineWidth',1.5)
bar(transpose([h20_mean; m20_mean]))
axis([0.5,46.5,0,1600])
colormap('gray')



